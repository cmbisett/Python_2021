from mysqlconnection import connectToMySQL

from flask.app.models import ninja
